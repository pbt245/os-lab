make clean
make all
./ex5

echo "Execution complete."