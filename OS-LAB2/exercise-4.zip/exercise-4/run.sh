# chmod +x run.sh
# before ./run.sh

make clean
make all
./my_program
